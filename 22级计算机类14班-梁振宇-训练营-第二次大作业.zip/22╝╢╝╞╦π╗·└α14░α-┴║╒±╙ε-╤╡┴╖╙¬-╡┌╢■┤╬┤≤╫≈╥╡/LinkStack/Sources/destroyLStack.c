#include"LinkStack.h"
#include<stdlib.h>
#include<stdio.h>
Status destroyLStack(LinkStack* s)
{

	while (s->top != NULL)
	{
		LinkStackPtr sub = s->top;
		s->top = s->top->next;
		free(sub);
	}
	free(s);//��������ջ
	s = NULL;
	if (s == NULL)return SUCCESS;
	else return ERROR;
}