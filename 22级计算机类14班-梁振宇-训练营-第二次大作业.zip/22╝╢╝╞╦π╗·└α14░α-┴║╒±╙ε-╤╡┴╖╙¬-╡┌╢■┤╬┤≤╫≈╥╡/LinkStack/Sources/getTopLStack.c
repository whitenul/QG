#include<stdio.h>
#include"LinkStack.h"
#include<stdio.h>
Status getTopLStack(LinkStack* s, ElemType* e)
{
	if (!s) {
		printf("The stack is not created!\n");
		return ERROR;
	}
	if (!s->top)
	{
		printf("The stack is empty.\n");
		return ERROR;
	}
	*e = s->top->data;
	if (*e == s->top->data)return SUCCESS;
	else return ERROR;
}