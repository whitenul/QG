#include"LinkStack.h"
#include<stdlib.h>
#include<stdio.h>
Status LStackLength(LinkStack* s, int* length)
{
	*length = 0;
	LinkStackPtr stk = s->top;
	while (stk != NULL)
	{
		(*length)++;
		stk = stk->next;
	}
	if (stk == NULL)
	{
		return SUCCESS;
	}	
	else
	{
		return ERROR;
	}
}