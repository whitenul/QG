#include<stdio.h>
void Menu(void)
{
	printf("\t\t\t***********************************************************\n");
	printf("\t\t\t\t\t\tLinkStack\n");
	printf("\t\t\t\t\t\t1.Initstack\n");
	printf("\t\t\t\t\t\t2.isEmptystack\n");
	printf("\t\t\t\t\t\t3.pushstack\n");
	printf("\t\t\t\t\t\t4.popstack\n");
	printf("\t\t\t\t\t\t5.getTopstack\n");
	printf("\t\t\t\t\t\t6.Lstacklength\n");
	printf("\t\t\t\t\t\t7.clearstack\n");
	printf("\t\t\t\t\t\t8.destorystack\n");
	printf("\t\t\t\t\t\t9.Fouroperations(��������)\n");
	printf("\t\t\t\t\t\t10.exit\n");
	printf("\t\t\t***********************************************************\n");
}