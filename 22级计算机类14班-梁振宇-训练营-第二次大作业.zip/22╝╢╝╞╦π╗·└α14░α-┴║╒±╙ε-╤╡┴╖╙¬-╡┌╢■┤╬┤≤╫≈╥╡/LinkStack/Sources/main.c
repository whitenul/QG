#include"LinkStack.h"
#include<stdio.h>
#include<ctype.h>
#include<stdlib.h>
#include<Windows.h>
int main()
{
	int i;
	LinkStack* s=NULL;
	do
	{
		Menu();
		printf("please input opertion number��1~10����");
		//�ж�������ǲ�������
		if (!scanf_s("%d", &i)) {
			int ch;		
			printf("Error,please input again��\n");
			//��ջ�����
			while ((ch = getchar()) != '\n' && ch!= EOF);
			i = 0;
			system("pause");
			system("cls");
			continue;
		}
		//�ж�����Ĳ������Ƿ���ȷ
		else if (i<= 0 || i >= 11 ) {
			printf("Error,please input again��\n");
			i = 0;
			system("pause");
			system("cls");
			continue;
		}
		//�˳�ϵͳ
		else if (i == 10) {
			printf("System exiting...\n");
			printf("3...\n");
			Sleep(1000);
			printf("2...\n");
			Sleep(1000);
			printf("1...\n");
			Sleep(1000);
			return 0;
		}
		else switch (i) {
//**********
		//��ʼ����ջ
		case 1:	
			//�����ջ�Ƿ��Ѿ����ڣ����ھ���Ҫ������
			if (s) {
				printf("The stack has been creat,please destroy it first!\n");
				system("pause");
				system("cls");
				continue;
			}
			s=(LinkStack*)malloc(sizeof(LinkStack));
			if (!s)
			{
				printf("Error!\n");
				system("pause");
				system("cls");
				continue;
			}
			s->count = -1;
			if (!s)
			{
				printf("Creat fail!\n");
				printf("plaese try again!\n");
				continue;
			}
			s->count = 0;
			if (initLStack(s) == TRUE)
			{
				printf("Create success.\n");
			}
			break;	
//**********
		//�ж���ջ�Ƿ�Ϊ�գ�Ϊ�շ���1���ǿշ���0
		case 2:
		{
			//�����ջ�Ƿ��Ѿ�����
			if (!s) {
				printf("This stack is not created.\n");
				system("pause");
				system("cls");
				continue;
			}
			int i=isEmptyLStack(s);
			if (i == 1)
			{
				printf("The stack is empty.\n");
			}
			else if(i==0)
			{
				printf("The stack is not empty.\n");
			}
			break;
		}			
//**********
		//Ԫ����ջ
		case 3:
		{
			if (!s) {
				printf("The stack is not created!\n");
				system("pause");
				system("cls");
				continue;
			}
			ElemType data ;
			printf("Please enter the data for the stack node you want to push:");
			scanf_s("%d", &data);
			int i=pushLStack(s, data);
			if (i == 1)
			{
				printf("Push success!\n");
			}
			else if (i == 0)
			{
				printf("Push fail.\n");
			}
			break;
		}
//**********
		//Ԫ�س�ջ
		case 4:
		{
			if (!s) {
				printf("The stack is not created!\n");
				system("pause");
				system("cls");
				continue;
			}
			if (!s->top)
			{
				printf("The stack is empty!\n");
				system("pause");
				system("cls");
				continue;
			}
			ElemType* e=(int*)malloc(sizeof(int));
			int i = popLStack(s,e);
			if (i == 1)
			{
				printf("Pop success!\n");
			}
			i = *e;
			printf("element %d is remove from the stack.\n", i);
			break;
		}			
//**********
		//��ȡ��ջջ����Ԫ��
		case 5:
		{
			ElemType* e = (int*)malloc(sizeof(int));
			int i=getTopLStack(s,e);
			if (i == 1)
			{
				i = *e;
				printf("The top element of the stack is %d.\n",i);
			}
			break;
		}
//**********
		//��ȡ��ջ�ĳ���
		case 6:
		{
			if (!s) {
				printf("The stack is not created!\n");
				system("pause");
				system("cls");
				continue;
			}
			ElemType* length = (int*)malloc(sizeof(int));
			if (!length)
			{
				printf("Error!\n");
				system("pause");
				system("cls");
			}
			*length = 0;
			LStackLength(s,length);
			printf("The length of the stack is %d.\n", *length);
			break;
		}
//**********
		//���ջ
		case 7:
			if (clearLStack(s) == TRUE)
			{
				printf("Clear success.\n");
			}
			break;
//**********
		//����ջ
		case 8:
		{
			if (!s) 
			{
				printf("The stack is not created!\n");
				system("pause");
				system("cls");
				continue;
			}
			int i=destroyLStack(s);
			if (i == 1)
			{
				printf("Destroy syccess!\n");
			}
			s = NULL;
			break;
		}
			
//**********
		//��������
		case 9:
			FourOperations();
			break;
		}
		system("pause");
		system("cls");
		system("color 0F");
		char c;
		while ((c = getchar()) != '\n' && c != EOF);
	} while (i>=0 && i <= 10);
}