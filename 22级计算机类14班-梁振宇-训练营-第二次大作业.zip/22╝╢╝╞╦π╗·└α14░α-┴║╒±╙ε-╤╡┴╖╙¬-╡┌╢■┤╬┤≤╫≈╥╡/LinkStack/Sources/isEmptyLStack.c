#include"LinkStack.h"
#include<stdlib.h>
#include<stdio.h>
Status isEmptyLStack(LinkStack* s)
{
	if (!s) {
		printf("The stack is not created!\n");
		return ERROR;
	}
	if (s->top == NULL)return SUCCESS;
	else return ERROR;
}