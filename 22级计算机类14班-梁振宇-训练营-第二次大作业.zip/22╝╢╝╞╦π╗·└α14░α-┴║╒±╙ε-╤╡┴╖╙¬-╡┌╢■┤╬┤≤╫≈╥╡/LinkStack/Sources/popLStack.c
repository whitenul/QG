#include"LinkStack.h"
#include<stdlib.h>
#include<stdio.h>
Status popLStack(LinkStack* s, ElemType* data)
{
	LinkStackPtr stk = s->top;
	*data = s->top->data;
	s->top = s->top->next;
	free(stk);
	s->count--;
	if (!stk)
	{
		return SUCCESS;
	}
	else
	{
		return ERROR;
	}
}