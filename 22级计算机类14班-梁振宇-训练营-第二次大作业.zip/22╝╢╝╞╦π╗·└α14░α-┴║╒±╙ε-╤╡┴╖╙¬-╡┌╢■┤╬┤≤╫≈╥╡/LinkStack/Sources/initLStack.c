#include"LinkStack.h"
#include<stdlib.h>
#include<stdio.h>
Status initLStack(LinkStack* s)
{
	s->top = (LinkStackPtr)malloc(sizeof(StackNode));
	s->top = NULL;
	s->count = 0;
	if (s->count== 0)//����Ϊ-1
	{
		return SUCCESS;
	}
	else
	{
		return ERROR;
	}
}