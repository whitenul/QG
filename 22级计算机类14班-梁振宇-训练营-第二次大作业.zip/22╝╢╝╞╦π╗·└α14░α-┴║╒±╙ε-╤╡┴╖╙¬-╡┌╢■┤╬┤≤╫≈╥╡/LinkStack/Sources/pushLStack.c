#include"LinkStack.h"
#include<stdlib.h>
#include<stdio.h>
Status pushLStack(LinkStack* s, ElemType data)
{
	//����һ���ڵ�
	LinkStackPtr stknode = (LinkStackPtr)malloc(sizeof(StackNode));
	if (!stknode)
	{
		return ERROR;
	}
	stknode->data = data;
	stknode->next = s->top;
	s->top = stknode;
	s->count++;
	if (s->top == stknode)
	{
		return SUCCESS;
	}
	else
	{
		return ERROR;
	}
}

