#include"LinkStack.h"
#include<stdlib.h>
#include<stdio.h>
Status  clearLStack(LinkStack* s)
{
	if (!s) {
		printf("The stack is not created!\n");
		return ERROR;
	}
	while (s->top != NULL)
	{
		LinkStackPtr sub = s->top;
		s->top = s->top->next;
		free(sub);
	}
	s->count = 0;//���ջ��������ջ�Ĳ�������
	s->top = NULL;
	if (s->top == NULL)
		return SUCCESS;
	else 
		return ERROR;
}