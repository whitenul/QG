#include"LQueue.h"
int LengthLQueue(LQueue* Q)
{
	return Q->length;
}