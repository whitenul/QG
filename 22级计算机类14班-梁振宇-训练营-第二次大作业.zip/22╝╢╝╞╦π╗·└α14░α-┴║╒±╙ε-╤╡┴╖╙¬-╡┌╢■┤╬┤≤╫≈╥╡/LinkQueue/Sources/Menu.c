#include<stdio.h>
void Menu(void)
{
	printf("\t\t\t***********************************************************\n");
	printf("\t\t\t\t\t\tLinkQueue\n");
	printf("\t\t\t\t\t\t1.InitQueue\n");
	printf("\t\t\t\t\t\t2.IsEmptyLQueue\n");
	printf("\t\t\t\t\t\t3.EnLQueue\n");
	printf("\t\t\t\t\t\t4.DLQueue\n");
	printf("\t\t\t\t\t\t5.getHeadLQueue\n");
	printf("\t\t\t\t\t\t6.LengthLQueue\n");
	printf("\t\t\t\t\t\t7.ClearLQueue\n");
	printf("\t\t\t\t\t\t8.DestoryLQueue\n");
	printf("\t\t\t\t\t\t9.TraverseLQueue\n");
	printf("\t\t\t\t\t\t10.Exit\n");
	printf("\t\t\t***********************************************************\n");
}