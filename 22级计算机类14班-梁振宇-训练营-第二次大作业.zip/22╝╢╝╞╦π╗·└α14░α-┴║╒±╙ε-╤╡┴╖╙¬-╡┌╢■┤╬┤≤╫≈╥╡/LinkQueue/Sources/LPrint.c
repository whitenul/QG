#include"LQueue.h"
#include<stdio.h>
void LPrint(void* q)
{
	switch (type)
	{
	case 'i':
		printf("%d", *(int*)q);
		break;
	case 'c':
		printf("%c", *(char*)q);
		break;
	case 'f':
		printf("%.2f", *(float*)q);
		break;
	}
}