#include"LQueue.h"
#include<stdlib.h>
#include<stdio.h>
Status DeLQueue(LQueue* Q)
{
	if (!Q)
	{
		printf("Queue does not exist.\n");
		return FALSE;
	}
	if (!Q->front)
	{
		printf("Queue is empty.\n");
		return FALSE;
	}
	Node* q = Q->front;
	Q->front = Q->front->next;
	Q->length--;
	free(q);
	return TRUE;
}