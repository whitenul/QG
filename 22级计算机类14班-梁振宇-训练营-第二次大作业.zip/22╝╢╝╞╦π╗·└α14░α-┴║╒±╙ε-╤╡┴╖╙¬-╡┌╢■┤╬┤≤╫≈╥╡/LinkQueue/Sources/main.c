#include"LQueue.h"
#include<stdio.h>
#include<stdlib.h>
#include<Windows.h>
int main()
{
	int i;
	LQueue* Q = NULL;
	void(*foo)(void*);//��������ָ��
	foo = LPrint;
	do
	{
		//�ж���Ҫ�������������
		system("color 06");
		printf("\t\t\t***********************************************************\n");
		printf("\t\t\t      Please enter the type of data you want to output\n");
		printf("\t\t\t\t\t    input 'i' mean 'int'\n");
		printf("\t\t\t\t\t    input 'c' mean 'char'\n");
		printf("\t\t\t\t\t    input 'f' mean 'float'\n");
		printf("\t\t\t***********************************************************\n");
		printf("Enter your choice:");
		type = getchar();
		char ch;//��ջ�����������Ԫ��
		while ((ch = getchar()) != '\n' && ch != EOF);
		if (type != 'i' && type != 'c' && type != 'f')
		{
			system("color 04");
			printf("Error,please input again.\n");
			system("pause");
		}
		system("cls");
		
	} while (type!='i'&&type!='c'&&type!='f');
	system("color 0F");
	do
	{
		Menu();
		printf("please input opertion number��1~10����");
		//�ж�������ǲ�������
		if (!scanf_s("%d", &i)) {
			int ch;
			printf("Error,please input again��\n");
			//��ջ�����
			while ((ch = getchar()) != '\n' && ch != EOF);
			i = 0;
			system("pause");
			system("cls");
			continue;
		}
		//�ж�����Ĳ������Ƿ���ȷ
		else if (i <= 0 || i >= 11) {
			printf("Error,please input again��\n");
			i = 0;
			system("pause");
			system("cls");
			continue;
		}
		//�˳�ϵͳ
		else if (i == 10) {
			printf("System exiting...\n");
			printf("3...\n");
			Sleep(1000);
			printf("2...\n");
			Sleep(1000);
			printf("1...\n");
			Sleep(1000);
			return 0;
		}
		//ִ�з��Ͷ��еĲ���
		else
		{
			switch (i)
			{
			//��ʼ��
			case 1:
				//�ж��Ƿ��Ѿ���ʼ���ˣ�����Ѿ���ʼ���˾���Ҫ���ٶ�����
				if (Q)
				{
					printf("Queue exists, please destroy first.\n");
					system("pause");
					system("cls");
					continue;
				}
				//δ��ʼ�������һ���ڴ�
				Q = (LQueue*)malloc(sizeof(LQueue));
				if (!Q)
				{
					printf("Creat fail,please try again.\n");
					system("pause");
					system("cls");
					continue;
				}
				//��ʼ�����еĳ���
				Q->length = 0;
				InitLQueue(Q);
				break;
			//�ж϶����Ƿ�Ϊ��
			case 2:
			{
				if (!Q)
				{
					printf("Queue does not exist.\n");
					system("pause");
					system("cls");
					continue;
				}
				int i = IsEmptyLQueue(Q);
				if (i == 1)
				{
					printf("Queue is empty.\n");
				}
				else
				{
					printf("Queue is not empty.\n");
				}
				break;
			}
			//Ԫ�����
			case 3:
			{
				if (!Q)
				{
					printf("Queue does not exist.\n");
					system("pause");
					system("cls");
					continue;
				}
				void* data = (void*)malloc(21);
				data = NULL;
				switch (type)
				{
				case 'i':
				{
					int* p = (int*)malloc(sizeof(int));
					printf("Enter a int number:");
					scanf_s("%d", p);
					data = (void*)p;
					break;
				}
				case 'c':
				{
					char* p = (char*)malloc(sizeof(char));
					printf("Enter a char:");
					getchar();
					scanf_s("%c", p, 1);
					data = (void*)p;
					break;
				}
				case 'f':
				{
					float* p = (float*)malloc(sizeof(float));
					printf("Enter a float number:");
					scanf_s("%f", p);
					data = (void*)p;
					break;
				}
				}
				EnLQueue(Q, data);
				break;
			}
			//Ԫ�س���
			case 4:
			{
				int i=DeLQueue(Q);
				if (i == 1)
				{
					printf("Delete success.\n");
				}
				break;
			}
			//��ȡ����Ԫ��
			case 5:
			{
				void*e=NULL;
				int i = GetHeadLQueue(Q, e);
				if (i == 1)
				{
					printf("The head element is ");
					if (!Q)
					{
						printf("Error.\n");
						return FALSE;
					}
					LPrint(Q->front->data);
					printf("\n");
				}
				break;
			}
			//��ȡ���еĳ���
			case 6:
			{
				if (!Q)
				{
					printf("Queue does not exist.\n");
					system("pause");
					system("cls");
					continue;
				}
				int i=LengthLQueue(Q);
				printf("The length of the queue is %d.\n", i);
				break;
			}
			//��ն���
			case 7:
			{
				if (!Q)
				{
					printf("Queue does not exist.\n");
					system("pause");
					system("cls");
					continue;
				}
				ClearLQueue(Q);
				break;
			}
			//���ٶ���
			case 8:
			{
				DestoryLQueue(Q);
				Q = NULL;
				break;
			}
			//��������
			case 9:
			{
				TraverseLQueue(Q, foo);
				break;
			}		
			}
		}
		system("pause");
		system("cls");
		fflush(stdin);
	} while (i >= 0 && i <= 10);
}
