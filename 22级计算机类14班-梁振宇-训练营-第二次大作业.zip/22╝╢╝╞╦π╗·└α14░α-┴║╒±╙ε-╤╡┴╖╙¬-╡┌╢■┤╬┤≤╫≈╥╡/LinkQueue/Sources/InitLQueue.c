#include"LQueue.h"
#include<stdlib.h>
#include<stdio.h>
void InitLQueue(LQueue* Q)
{
	Q->front = NULL;
	Q->rear = Q->front;
}