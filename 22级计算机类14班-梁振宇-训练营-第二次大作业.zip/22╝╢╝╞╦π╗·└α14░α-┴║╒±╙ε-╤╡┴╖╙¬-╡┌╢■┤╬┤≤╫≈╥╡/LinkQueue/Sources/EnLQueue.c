#include"LQueue.h"
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
Status EnLQueue(LQueue* Q, void* data)
{
	if (IsEmptyLQueue(Q) == TRUE)
	{
		Q->rear=Q->front = (Node*)malloc(sizeof(Node));
		Q->rear->data = data;
		Q->rear->next = NULL;
		Q->length++;
		return TRUE;
	}
	else
	{
		Node* q = Q->rear;
		Q->rear = (Node*)malloc(sizeof(Node));
		if (!Q->rear)
		{
			printf("Error.\n");
			return FALSE;
		}
		Q->rear->data = data;
		Q->rear->next = NULL;
		q->next = Q->rear;
		Q->length++;
		return TRUE;
	}
}