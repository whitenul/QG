#include"LQueue.h"
#include<stdio.h>
Status GetHeadLQueue(LQueue* Q, void* e)
{
	if (!Q)
	{
		printf("Queue does not exist.\n");
		return FALSE;
	}
	if (!Q->front)
	{
		printf("Queue is empty.\n");
		return FALSE;
	}
	void* p = Q->front->data;
	e = p;
	if (Q->front->data == e)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}