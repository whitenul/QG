#include"LQueue.h"
#include<stdlib.h>
#include<stdio.h>
void DestoryLQueue(LQueue* Q)
{
	if (!Q)
	{
		printf("Queue does not exist.\n");
		return;
	}
	free(Q);
	Q = NULL;
	if (Q == NULL)
	{
		printf("Destory success.\n");
	}
}