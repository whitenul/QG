#include"LQueue.h"
#include<stdio.h>
#include<stdlib.h>
void ClearLQueue(LQueue* Q)
{
	if (!Q)
	{
		printf("Queue does not exist.\n");
		return;
	}
	Node* p = Q->front;
	LQueue* q = Q;
	
	while (q->front)
	{
		Node*node = q->front;
		q->front = q->front->next;
		free(node);
	}
	q->front = p;
	Q->front = NULL;
	Q->rear = Q->front;
	Q->length = 0;
	if (Q->front == Q->rear && Q->front == NULL)
	{
		printf("Clear success.\n");
	}
}