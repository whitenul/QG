#include"LQueue.h"
#include<stdio.h>
Status TraverseLQueue(const LQueue* Q, void (*foo)(void* q))
{
	
	if (!Q)
	{
		printf("Queue does not exist.\n");
		return FALSE;
	}
	if (!Q->front)
	{
		printf("Queue is empty.\n");
		return FALSE;
	}
	Node* p = Q->front;
	LQueue* q = Q;
	while (q->front)
	{
		foo(q->front->data);
		printf("-->");
		q->front = q->front->next;
	}
	q->front = p;
	printf("NULL\n");
	return TRUE;
}