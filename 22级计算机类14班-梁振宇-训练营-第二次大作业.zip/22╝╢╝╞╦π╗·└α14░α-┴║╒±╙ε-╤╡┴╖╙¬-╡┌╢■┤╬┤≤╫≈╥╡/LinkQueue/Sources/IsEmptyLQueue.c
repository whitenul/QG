#include"LQueue.h"
#include<stdlib.h>
Status IsEmptyLQueue(const LQueue* Q)
{
	if (Q->front == Q->rear && Q->front == NULL)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}