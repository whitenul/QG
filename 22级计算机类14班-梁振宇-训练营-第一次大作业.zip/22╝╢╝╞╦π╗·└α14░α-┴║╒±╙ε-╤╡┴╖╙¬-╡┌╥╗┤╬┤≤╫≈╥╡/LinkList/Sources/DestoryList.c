#include<stdio.h>
#include<stdlib.h>
#include"linkedList.h"
void DestroyList(LinkedList* L) {
	LNode* p = NULL;
	while ((*L)->next) {
		p = *L;
		(*L) = (*L)->next;
		free(p);
	}
	 (*L) = NULL;
}