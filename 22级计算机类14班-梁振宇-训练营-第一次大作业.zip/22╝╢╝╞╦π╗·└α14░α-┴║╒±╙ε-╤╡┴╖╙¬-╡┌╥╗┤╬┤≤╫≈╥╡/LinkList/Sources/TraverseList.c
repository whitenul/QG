#include<stdio.h>
#include<stdlib.h>
#include"linkedList.h"
void TraverseList(LinkedList L, void (*visit)(ElemType e)) {
	if (L == NULL) {
		printf_s("NULL\n");
		return;
	}
	LinkedList p = L;
	//��������
	while (p) {
		visit(p->data);
		p = p->next;
	}
	printf_s("NULL\n");
}