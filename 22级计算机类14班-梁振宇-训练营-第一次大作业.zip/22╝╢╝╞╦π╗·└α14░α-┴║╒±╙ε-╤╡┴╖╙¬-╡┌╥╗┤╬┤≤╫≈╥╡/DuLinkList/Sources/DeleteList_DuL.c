#include<stdio.h>
#include<stdlib.h>
#include"duLinkedList.h"
Status DeleteList_DuL(DuLNode* p, ElemType* e) {
	if (p == NULL) {
		printf_s("δ��ʼ������\n");
		return ERROR;
	}
	*e = p->next->data;
	p->next = p->next->next;
	if (p->next != NULL) {
		p->next->prior = p;
	}
	else p->next = NULL;
	return SUCCESS;
}